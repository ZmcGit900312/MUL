#include "stdafx.h"
#include "CoreAPI.h"
#include "Const.h"
#include "Data.h"
#include "IntegrationRWG.h"
#include "Log.h"

int Core::PreCalculateSelfTriangleImpedance()
{
	//�ػ�RWG������ʹ�ã�Ԥ�ȼ��������ε����迹
	cout << '\n';
	Console->info("Begin to pre-compute the SelfTriangle Impedance");
	RuntimeL->info("Begin to pre-compute the SelfTriangle Impedance");
	const clock_t start = clock();
#pragma region RWGSET
	for (auto i = ComponentList::MeshService->TriangleVector()->begin(),
		e= ComponentList::MeshService->TriangleVector()->end(); i != e; ++i)
	{
		EFRImp::SetSelfImpedanceTriangle(*i, W13, k, eta);
	}
	const clock_t end = clock();
	const double time = double(end - start) / CLOCKS_PER_SEC;
	//
	Console->info("Pre-compute SelfTriangle Impedance costs:\t{} s", time);
	ResultL->info("Pre-compute SelfTriangle Impedance costs:\t{} s", time);
	RuntimeL->info("Finish Pre-compute");
	RuntimeL->flush();
#pragma endregion 
	return 0;
}
