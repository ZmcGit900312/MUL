///////////////////////////////////////////////////////////
//  Cuboid.h
//  Implementation of the Class Cuboid
//  Created on:      24-4��-2018 14:20:21
//  Original author: ZhengMX
///////////////////////////////////////////////////////////

#pragma once
#include <Eigen/Core>

using namespace Eigen;

namespace Core
{
	class Cuboid{};
}

