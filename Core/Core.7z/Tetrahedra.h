///////////////////////////////////////////////////////////
//  Tetrahedra.h
//  Implementation of the Class Tetrahedra
//  Created on:      24-4��-2018 14:17:39
//  Original author: ZhengMX
///////////////////////////////////////////////////////////

#pragma once
#include <Eigen/Core>
#include <map>

using namespace Eigen;
using namespace std;

namespace Core
{
	class Tetrahedra{};
}

