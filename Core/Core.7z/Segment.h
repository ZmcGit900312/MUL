///////////////////////////////////////////////////////////
//  Segment.h
//  Implementation of the Class Triangle
//  Created on:      24-4��-2018 14:15:53
//  Original author: ZhengMX
///////////////////////////////////////////////////////////

#pragma once
#include <Eigen/Core>
#include <map>

using namespace Eigen;
using namespace std;


namespace Core
{
	class Segment
	{};
}