///////////////////////////////////////////////////////////
//  RWG.h
//  Implementation of the Interface IIBasicFunction
//  Created on:      04-05��-2018 15:56:35
//  Original author: ZhengMX
///////////////////////////////////////////////////////////

#pragma once
#include "IBasicFunction.h"
#include "Triangle.h"
#include <map>
using namespace std;

namespace Core {
	class Mesh;

	class RWG :public IBasicFunction
	{
	public:
		RWG(const size_t id,const pair<int, Vector3d> node[4], Triangle& tplus, Triangle& tminus);
		~RWG() { _tplus = nullptr, _tminus = nullptr; }

		//Get Private Variable API
		size_t GetID()const override { return _id; }
		double Length()const { return _edgeLength; }
		Vector3d Node(const int val)const { return _node[val].second; }
		Vector3d Centre()const { return _centre; }
		Triangle& TrianglePlus() const { return *_tplus; }
		Triangle& TriangleMinus() const { return *_tminus; }
		dcomplex& Current()override { return _current; }

		//Current and Charge Function 
		Vector3d CurrentPlus(const Vector3d val)const override;
		Vector3d CurrentMinus(const Vector3d val)const override;
		double ChargePlus(const Vector3d)const override { return _edgeLength / _tplus->Area(); }
		double ChargeMinus(const Vector3d)const override { return -_edgeLength / _tminus->Area(); }
		int LimitPlus()const override { return _tplus->ID(); }
		int LimitMinus()const override { return _tminus->ID(); }
		
		/**
		* \brief �Զ�������ʽ���浱�µ�RWG��������Ϣ
		* \n Format is [ID trianglePlusID triangleMinusID nodePlusID nodeMinusID nodeLeftID nodeRightID current]
		* \param ofs д����ļ���
		*/
		void SaveBinary(ofstream &ofs)override;
		/**
		* \brief ��̬����������RWG������
		* \param mesh �ʷ�����
		* \param RWGList ����������
		* \return ����������
		*/
		static size_t CreatRWGBasicFunctionList(Mesh* mesh,vector<IBasicFunction*>*RWGList);

	private:	
		size_t _id = 0;
		/**
		 * \brief Four nodes in one RWG
		 * plus		0
		 * minus	1
		 * left		2
		 * right	3
		 */
		pair<int, Vector3d> _node[4];
		Vector3d _centre;
		complex<double> _current{ 0,0 };
		double _edgeLength;
		Triangle *_tplus, *_tminus;	
	};
}
